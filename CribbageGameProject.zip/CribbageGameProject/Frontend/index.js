
  /*
      // Add click event to move card to crib
      cardElement.addEventListener('click', function () {
        // Move the clicked card to crib (example move)
        //const crib = document.querySelector('.crib-cards');
        //crib.appendChild(cardElement);
        //cardElement.style.backgroundImage = `url(${cardBackImgPath})`; // Change card image

        // Move the clicked card to crib without displaying it immediately
        cardElement.classList.add('in-crib'); // Add a class indicating the card is in the crib
        cribContainer.appendChild(cardElement);
        cardElement.style.display = 'none'; // Hide the card in the crib
      });

      return cardElement;
  }*/
